//
//  CoreDataManager.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import CoreData

public class CoreDataManager: NSObject, NSFetchedResultsControllerDelegate {
    public static let shared = CoreDataManager()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let bundle = Bundle(identifier: "com.graphixware.RecordingsStoreFW")
        let bundleURL = bundle?.url(forResource: "RecordingsStore", withExtension: "momd")
        let mom = NSManagedObjectModel(contentsOf: bundleURL!)
        let container = NSPersistentContainer(name: "Configuration", managedObjectModel: mom!)
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let err = error as NSError? {
                print("CoreDataManager.persistentContainer: container.loadPersistentStores() failed with error \(err.localizedDescription)")
            }
        })
        
        return container
    }()
    
    lazy var configurationFRC: NSFetchedResultsController<Configuration> = { [weak self] in
        guard let strongSelf = self else { fatalError("CoreDataManager.registrationFRC: Fatal error encountered during initialization.") }
        
        let fetchRequest: NSFetchRequest<Configuration> = Configuration.fetchRequest()
        
        let sortDescriptor = NSSortDescriptor(key: "publishRecordings", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        let controller = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: strongSelf.persistentContainer.viewContext,
            sectionNameKeyPath: nil, cacheName: "ConfigurationCache")
        
        return controller
    }()
    
    public func fetchConfiguration(completionHandler: @escaping (_ error: Error?, Configuration?) -> Void) {
        do {
            try configurationFRC.performFetch()
            
            completionHandler(nil, configurationFRC.fetchedObjects?.first)
        } catch let error as NSError {
            print("CoreDataManager.fetchConfiguration() failed with error \(error.localizedDescription)")
            
            completionHandler(error, nil)
        }
    }

    public func saveConfiguration(existingMO: NSManagedObject?, publishRecordings: Bool, trackCount: Int16,
        completionHandler: @escaping (_ configuration: NSManagedObject?, _ error: Error?) -> Void) {
        var configuration = existingMO
        
        if configuration == nil {
            let managedObjectContext = persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "Configuration", in: managedObjectContext)!
            configuration = NSManagedObject(entity: entity, insertInto: managedObjectContext)
        }
        
        configuration?.setValue(publishRecordings, forKeyPath: "publishRecordings")
        configuration?.setValue(trackCount, forKeyPath: "trackCount")
        
        saveManagedObjectContext { [weak self] (error) in
            guard let strongSelf = self else { return }
            
            if error != nil {
                print("CoreDataManager.saveConfiguration() failed with error \(String(describing: error?.localizedDescription))")
                
                completionHandler(nil, error)
            } else {
                strongSelf.fetchConfiguration { error, configuration in
                    completionHandler(configuration, error)
                }
            }
        }
    }
    
    func saveManagedObjectContext(completionHandler: @escaping (_ error: Error?) -> Void) {
        let managedObjectContext = persistentContainer.viewContext
        
        do {
            try managedObjectContext.save()
            
            completionHandler(nil)
        } catch {
            completionHandler(error)
        }
    }
}
