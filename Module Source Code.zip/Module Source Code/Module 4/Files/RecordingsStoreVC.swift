//
//  RecordingsStoreVC.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import SwiftUI

class RecordingsStoreVC: UIHostingController<RecordingsStoreView> {
    required init?(coder: NSCoder) {
        let view = RecordingsStoreView(viewModel: IAPViewModel(service: IAPService.shared, endpoint: .fetchInAppPurchases))
        
        super.init(coder: coder, rootView: view)
    }
}
