//
//  RecordingsStore.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import UIKit

protocol DisplayableViewController {
    func instantiateRootViewController() -> UIViewController
}

public class RecordingsStore: DisplayableViewController {
    public init() {}
    
    public func instantiateRootViewController() -> UIViewController {
        let storyboard = UIStoryboard(name: "RecordingsStore", bundle: Bundle(for: RecordingsStoreVC.self))
        let vc = storyboard.instantiateViewController(withIdentifier: "RecordingsStoreVC")
        return vc
    }
}
