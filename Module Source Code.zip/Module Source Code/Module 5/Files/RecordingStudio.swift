//
//  RecordingStudio.swift
//  RecordingStudioFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import UIKit

protocol DisplayableViewController {
    func instantiateRootViewController() -> UIViewController
}

public class RecordingStudio: DisplayableViewController {
    public init() {}
    
    public func instantiateRootViewController() -> UIViewController {
        let storyboard = UIStoryboard(name: "RecordingStudio", bundle: Bundle(for: RecordingStudio.self))
        let vc = storyboard.instantiateViewController(withIdentifier: "RecordingStudioNC")
        return vc
    }
}
