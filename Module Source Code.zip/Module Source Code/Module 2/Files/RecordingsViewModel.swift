//
//  RecordingsViewModel.swift
//  RecordingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation

class RecordingsViewModel: RefreshableViewModel {
    private(set) var recordings: [Recording]! {
        didSet {
            self.bindRecordingsViewModelToController()
        }
    }
    
    var bindRecordingsViewModelToController: (() -> ()) = {}
    
    init() {
    }
    
    func getRecordings() -> [Recording] {
        return recordings
    }
    
    func refresh() {
        fetch()
    }
    
    private func fetch() {
//        RecordingsService.shared.fetch() { [weak self] recordings, error in
//            guard let strongSelf = self else { return }
//            
//            if let err = error {
//                print("RecordingsViewModel.fetch(): error = \(err.localizedDescription)")
//            } else {
//                strongSelf.recordings = recordings
//            }
//        }
    }
}
