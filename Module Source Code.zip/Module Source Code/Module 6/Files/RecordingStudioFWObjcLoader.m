//
//  RecordingStudioFWObjcLoader.m
//  RecordingStudioFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import "RecordingStudioFWObjcLoader.h"
#import "RecordingStudioFW/RecordingStudioFW-Swift.h"

@implementation RecordingStudioFWObjcLoader

// https://developer.apple.com/documentation/objectivec/nsobject/1418815-load

+(void) load {
    if ([[RecordingStudioFWSwiftLoader alloc] init]) {
        NSLog(@"RecordingStudioFWObjcLoader.load() succeeded...");
    } else {
        NSLog(@"RecordingStudioFWObjcLoader.load() failed...");
    }
}

@end
