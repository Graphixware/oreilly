//
//  RecordingsStoreFWSwiftLoader.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation

@objcMembers public class RecordingsStoreFWSwiftLoader: NSObject {
    override public init() {
        super.init()
        
        initViews()
        initFeatures()
    }
    
    func initViews() {
        let config = [ "bundle": "com.graphixware.RecordingsStoreFW", "storyboard": "RecordingsStore", "view": "RecordingsStoreVC", "title": "Pro Features", "icon": "music.note.list"]
        
        var configs: [[String:String]] = []
        
        if let persistedConfigs = UserDefaults.standard.object(forKey: "views") as? [Dictionary<String,String>], !persistedConfigs.isEmpty {
            configs.append(contentsOf: persistedConfigs)
            
            if !findConfig(configs: persistedConfigs) {
                configs.append(config)
            }
        } else {
            configs.append(config)
        }
        
        UserDefaults.standard.set(configs, forKey: "views")
    }
    
    func findConfig(configs: [[String:String]]) -> Bool {
        var found = false
        
        for config in configs {
            if config["bundle"] == "com.graphixware.RecordingsStoreFW", config["storyboard"] == "RecordingsStore", config["view"] == "RecordingsStoreVC"{
                found = true
                break
            }
        }
        
        return found
    }
    
    func initFeatures() {
        var publish = false
        var tracks: Int16 = 1
        
        CoreDataManager.shared.fetchConfiguration { error, configuration in
            if error != nil {
                print("RecordingStoreFWSwiftLoader.initFeatures.fetchConfiguration(): error = \(String(describing: error?.localizedDescription))")
            } else {
                if let config = configuration {
                    publish = config.publishRecordings
                    tracks = config.trackCount
                } else {
                    CoreDataManager.shared.saveConfiguration(existingMO: nil, publishRecordings: false, trackCount: 1) { configuration, error in
                        if error != nil {
                            print("RecordingsStoreFWSwiftLoader.initFeatures.saveConfiguration(): error = \(String(describing: error?.localizedDescription))")
                        } else {
                            if let config = configuration as? Configuration {
                                publish = config.publishRecordings
                                tracks = config.trackCount
                            }
                        }
                    }
                }
            }
        }
        
        UserDefaults.standard.set(["publishRecordings" : publish, "trackCount": tracks] as [String: Any], forKey: "features")
    }
}
