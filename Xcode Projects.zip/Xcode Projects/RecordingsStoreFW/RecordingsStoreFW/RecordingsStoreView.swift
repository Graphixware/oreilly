//
//  RecordingsStoreView.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import SwiftUI

struct RecordingsStoreView: View {
    @State private var selectedIAP: IAP?
    @State private var showAlert = false
    @State private var loaded = false
    @StateObject private var viewModel: IAPViewModel
    
    @State private var fontName: String
    @State private var fontSize: CGFloat
    
    init(viewModel: IAPViewModel, fontName: String = "HelveticaNeue", fontSize: CGFloat = 16.0) {
        _viewModel = StateObject(wrappedValue: viewModel)
        self.fontName = fontName
        self.fontSize = fontSize
    }
    
    func groupByCategory(_ iaps: [IAP]) -> [(String, [IAP])] {
        let grouped = Dictionary(grouping: iaps, by: { $0.category })
        return grouped.sorted(by: { $0.key < $1.key })
    }
    
    var body: some View {
        NavigationView {
            List(selection: $selectedIAP) {
                ForEach(groupByCategory(viewModel.getIAPs()), id:\.0) { iap in
                    Section(header: Text("\(iap.0)")
                        .font(.custom(fontName, size: fontSize))
                        .bold()
                    ){
                        ForEach(iap.1) { iap in
                            HStack {
                                Button("\(Image(systemName: "music.note")) \(iap.name)") {
                                    showAlert = true
                                    selectedIAP = iap
                                }
                                .font(.custom(fontName, size: fontSize))
                                Spacer()
                                Text("\(NumberFormatter.localizedString(from: NSNumber(value: iap.price), number: .currency))")
                                    .font(.custom(fontName, size: fontSize))
                                    .bold()
                            }
                            .listRowSeparator(.hidden)
                            .disabled(isPurchased(iap: iap))
                        }
                    }
                }
            }
            .listStyle(.plain)
            .navigationBarTitle("Pro Features", displayMode: .large)
            .alert("Pro Features", isPresented: $showAlert) {
                Button("OK") {
                    if let iap = selectedIAP {
                        updateFeatures(type: iap.type)
                    }
                }
                Button("Cancel") {}
            } message: {
                Text("Do you want to purchase \"\(selectedIAP?.name ?? "?")\"")
            }
        }
        .onAppear {
            if !loaded {
                loaded = true
                
                viewModel.refresh()
            }
        }
    }
    
    func isPurchased(iap: IAP) -> Bool {
        if let features = UserDefaults.standard.object(forKey: "iaps") as? [String: Any] {
            switch (iap.type) {
            case .publishRecordings:
                return features["publish"] as? Bool ?? false
            case .twoTracks:
                if let trackCount = features["tracks"] as? Int16 {
                    return trackCount > 1
                }
                
                return false
            case .threeTracks:
                if let trackCount = features["tracks"] as? Int16 {
                    return trackCount > 2
                }
                
                return false
            case .fourTracks:
                if let trackCount = features["tracks"] as? Int16 {
                    return trackCount > 3
                }
                
                return false
            }
        }
        
        return false
    }
    
    func updateFeatures(type: IAPType) {
        var mom: Configuration?
        
        CoreDataManager.shared.fetchConfiguration { error, configuration in
            if error != nil {
                print("RecordingsStoreView.updateFeatures(): error = \(String(describing: error?.localizedDescription))")
            } else {
                mom = configuration
            }
        }
        
        var publishRecordings = false
        var trackCount: Int16 = 1
        
        switch (type) {
        case .publishRecordings:
            publishRecordings = true
            trackCount = mom?.trackCount ?? 1
        case .twoTracks:
            publishRecordings = mom?.publishRecordings ?? false
            trackCount = 2
        case .threeTracks:
            publishRecordings = mom?.publishRecordings ?? false
            trackCount = 3
        case .fourTracks:
            publishRecordings = mom?.publishRecordings ?? false
            trackCount = 4
        }
        
        CoreDataManager.shared.saveConfiguration(existingMO: mom, publishRecordings: publishRecordings, trackCount: trackCount) { configuration, error in
            if error != nil {
                print("RecordingsStoreView.updateFeatures(): error = \(String(describing: error?.localizedDescription))")
            } else {
                if let config = configuration as? Configuration {
                    UserDefaults.standard.set(["publish" : config.publishRecordings, "tracks": config.trackCount] as [String: Any],
                                              forKey: "iaps")
                }
            }
        }
    }
}

struct RecordingsStoreView_Previews: PreviewProvider {
    static var previews: some View {
        RecordingsStoreView(viewModel: IAPViewModel(service: IAPService.shared, endpoint: .fetchInAppPurchases))
    }
}
