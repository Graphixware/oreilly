//
//  IAP.swift
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation

// https://github.com/AliSoftware/OHHTTPStubs
enum IAPEndpoint {
    case fetchInAppPurchases
    var urlString: String {
        switch self {
        case .fetchInAppPurchases:
            return "https://graphixware.com/iaps"
        }
    }
}

enum IAPError: Error {
    case request(message: String)
    case network(message: String)
    case status(message: String)
    case parsing(message: String)
    case other(message: String)
}

protocol RefreshableViewModel {
    func getIAPs() -> [IAP]
    func refresh()
}

enum IAPType: String, Decodable {
    case publishRecordings = "publishRecordings"
    case twoTracks = "twoTracks"
    case threeTracks = "threeTracks"
    case fourTracks = "fourTracks"
}

struct IAP: Hashable, Identifiable, Decodable {
    var id: String { name }
    let category: String
    let name: String
    let price: Double
    let type: IAPType
    
    init(category: String, name: String, price: Double, type: IAPType) {
        self.category = category
        self.name = name
        self.price = price
        self.type = type
    }
}
