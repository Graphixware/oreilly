//
//  RecordingsStoreFW.h
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RecordingsStoreFW.
FOUNDATION_EXPORT double RecordingsStoreFWVersionNumber;

//! Project version string for RecordingsStoreFW.
FOUNDATION_EXPORT const unsigned char RecordingsStoreFWVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RecordingsStoreFW/PublicHeader.h>


