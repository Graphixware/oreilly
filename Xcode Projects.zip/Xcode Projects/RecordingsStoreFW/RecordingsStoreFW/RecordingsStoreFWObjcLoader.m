//
//  RecordingsStoreFWObjcLoader.m
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import "RecordingsStoreFWObjcLoader.h"
#import "RecordingsStoreFW/RecordingsStoreFW-Swift.h"

@implementation RecordingsStoreFWObjcLoader

// https://developer.apple.com/documentation/objectivec/nsobject/1418815-load

+(void) load {
    if ([[RecordingsStoreFWSwiftLoader alloc] init]) {
        NSLog(@"RecordingsStoreFWSwiftLoader.load() succeeded...");
    } else {
        NSLog(@"RecordingsStoreFWSwiftLoader.load() failed...");
    }
}

@end
