//
//  RecordingsStoreFWObjcLoader.h
//  RecordingsStoreFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#ifndef RecordingsStoreFWObjcLoader_h
#define RecordingsStoreFWObjcLoader_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecordingsStoreFWObjcLoader : NSObject
@end

NS_ASSUME_NONNULL_END

#endif /* RecordingsStoreFWObjcLoader_h */
