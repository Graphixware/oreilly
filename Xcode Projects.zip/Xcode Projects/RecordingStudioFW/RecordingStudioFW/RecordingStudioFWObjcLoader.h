//
//  RecordingStudioFWObjcLoader.h
//  RecordingStudioFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#ifndef RecordingStudioFWObjcLoader_h
#define RecordingStudioFWObjcLoader_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecordingStudioFWObjcLoader : NSObject
@end

NS_ASSUME_NONNULL_END


#endif /* RecordingStudioFWObjcLoader_h */
