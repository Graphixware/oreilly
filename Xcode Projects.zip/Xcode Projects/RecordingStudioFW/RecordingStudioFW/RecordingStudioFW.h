//
//  RecordingStudioFW.h
//  RecordingStudioFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RecordingStudioFW.
FOUNDATION_EXPORT double RecordingStudioFWVersionNumber;

//! Project version string for RecordingStudioFW.
FOUNDATION_EXPORT const unsigned char RecordingStudioFWVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RecordingStudioFW/PublicHeader.h>


