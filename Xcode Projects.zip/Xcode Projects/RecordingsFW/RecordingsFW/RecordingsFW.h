//
//  RecordingsFW.h
//  RecordingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RecordingsFW.
FOUNDATION_EXPORT double RecordingsFWVersionNumber;

//! Project version string for RecordingsFW.
FOUNDATION_EXPORT const unsigned char RecordingsFWVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RecordingsFW/PublicHeader.h>


