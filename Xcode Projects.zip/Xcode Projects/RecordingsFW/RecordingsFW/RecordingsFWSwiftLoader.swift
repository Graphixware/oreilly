//
//  RecordingsFWSwiftLoader.swift
//  RecordingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation

@objcMembers public class RecordingsFWSwiftLoader: NSObject {
    override public init() {
        super.init()
        
        initViews()
    }
    
    func initViews() {
        let config = [ "bundle": "com.graphixware.RecordingsFW", "storyboard": "RecordingsFW", "view": "RecordingsNC", "title": "Recordings", "icon": "music.note.list"]
        
        var configs: [[String:String]] = []
        
        if let persistedConfigs = UserDefaults.standard.object(forKey: "views") as? [Dictionary<String,String>], !persistedConfigs.isEmpty {
            configs.append(contentsOf: persistedConfigs)
            
            if !findConfig(configs: persistedConfigs) {
                configs.append(config)
            }
        } else {
            configs.append(config)
        }
        
        UserDefaults.standard.set(configs, forKey: "views")
    }
    
    func findConfig(configs: [[String:String]]) -> Bool {
        var found = false
        
        for config in configs {
            if config["bundle"] == "com.graphixware.RecordingsFW", config["storyboard"] == "RecordingsFW", config["view"] == "RecordingsNC" {
                found = true
                break
            }
        }
        
        return found
    }
}
