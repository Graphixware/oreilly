//
//  RecordingsFWObjcLoader.m
//  RecordingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import "RecordingsFWObjcLoader.h"
#import "RecordingsFW/RecordingsFW-Swift.h"

@implementation RecordingsFWObjcLoader

// https://developer.apple.com/documentation/objectivec/nsobject/1418815-load

+(void) load {
    if ([[RecordingsFWSwiftLoader alloc] init]) {
        NSLog(@"RecordingsFWObjcLoader.load() succeeded...");
    } else {
        NSLog(@"RecordingsFWObjcLoader.load() failed...");
    }
}

@end
