//
//  Recordings.swift
//  RecordingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import UIKit

protocol DisplayableViewController {
    func instantiateRootViewController() -> UIViewController
}

public class Recordings: DisplayableViewController {
    public init() {}
    
    public func instantiateRootViewController() -> UIViewController {
        let storyboard = UIStoryboard(name: "RecordingsFW", bundle: Bundle(for: RecordingsTVC.self))
        let vc = storyboard.instantiateViewController(withIdentifier: "RecordingsNC")
        return vc
    }
}

protocol RefreshableViewModel {
    func getRecordings() -> [Recording]
    func refresh()
}

struct Recording: Codable {
    let bitrate: Int64
    let copyright: String
    let date: String
    let length: Int64
    let size: Int64
    var title: String
    let type: String
    let url: String
}

enum RecordingsEndpoint {
    case fetchRecordings
    var urlString: String {
        switch self {
        case .fetchRecordings:
            return "https://graphixware.free.beeceptor.com/oreilly/recordings"
        }
    }
}

enum RecordingsError: Error {
    case request(message: String)
    case network(message: String)
    case status(message: String)
    case parsing(message: String)
    case other(message: String)
}
