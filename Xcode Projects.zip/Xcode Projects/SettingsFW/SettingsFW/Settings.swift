//
//  Settings.swift
//  SettingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import Foundation
import UIKit

protocol DisplayableViewController {
    func instantiateRootViewController(configuration: Dictionary<String,Any>) -> UIViewController
}

public class Settings: DisplayableViewController {
    public init() {}
    
    public func instantiateRootViewController(configuration: Dictionary<String,Any>) -> UIViewController {
        let storyboard = UIStoryboard(name: "SettingsFW", bundle: Bundle(for: Settings.self))
        
        let vc = storyboard.instantiateViewController(withIdentifier: "SettingsNC")
        
        if let navController = vc as? UINavigationController {
            if let settingsTVC = navController.topViewController as? SettingsTVC {
                settingsTVC.configure(configuration: configuration)
            }
        }
        
        return vc
    }
}
