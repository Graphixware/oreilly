//
//  SettingsTVC.swift
//  SettingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

import UIKit

class SettingsTVC: UITableViewController {
    var configuration: Dictionary<String,Any>?
    
    func configure(configuration: Dictionary<String,Any>) {
        self.configuration = configuration
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.largeTitleDisplayMode = .always
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
}

