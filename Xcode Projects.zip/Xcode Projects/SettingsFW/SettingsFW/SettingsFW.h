//
//  SettingsFW.h
//  SettingsFW
//
//  Copyright © 2024 Graphixware, LLC. All Rights Reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SettingsFW.
FOUNDATION_EXPORT double SettingsFWVersionNumber;

//! Project version string for SettingsFW.
FOUNDATION_EXPORT const unsigned char SettingsFWVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SettingsFW/PublicHeader.h>


